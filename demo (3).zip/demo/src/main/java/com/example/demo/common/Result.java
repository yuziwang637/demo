package com.example.demo.common;

import lombok.Data;
import org.springframework.http.HttpStatus;

@Data
public class Result<T> {
    // 状态码：200成功，400参数错误，401未授权，500系统错误
    private int code;
    private String message;
    private T data;


    // 成功响应（带数据）
    public static <T> Result<T> success(T data) {
        Result<T> result = new Result<>();
        result.setCode(200);
        result.setMessage("操作成功");
        result.setData(data);
        return result;
    }

    // 失败响应（带消息）
    public static <T> Result<T> fail(String message) {
        Result<T> result = new Result<>();
        result.setCode(400);
        result.setMessage(message);
        return result;
    }

    // 自定义状态码响应
    public static <T> Result<T> build(int code, String message, T data) {
        Result<T> result = new Result<>();
        result.setCode(code);
        result.setMessage(message);
        result.setData(data);
        return result;
    }
}
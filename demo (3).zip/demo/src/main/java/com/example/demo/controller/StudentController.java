package com.example.demo.controller;

import com.example.demo.common.Result;
import com.example.demo.entity.InterviewStudent;
import com.example.demo.entity.Student;
import com.example.demo.service.InterviewResultService;
import com.example.demo.service.InterviewStudentService;
import com.example.demo.service.StudentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.InterviewResult;

import java.util.List;

@RestController
@RequestMapping("/student")
@Api(tags = "学生接口（统一返回格式）")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private InterviewStudentService interviewStudentService;

    @Autowired
    private InterviewResultService interviewResultService;

    /**
     * 学生注册
     */
    @PostMapping("/register")
    @ApiOperation("学生注册")
    public Result<String> register(@RequestBody Student student) {
        try {
            boolean success = studentService.register(student);
            return success ? Result.success("注册成功") : Result.fail("注册失败");
        } catch (Exception e) {
            return Result.fail("注册异常：" + e.getMessage());
        }
    }

    /**
     * 学生登录
     */
    @PostMapping("/login")
    @ApiOperation("学生登录")
    public Result<String> login(@RequestParam String studentId, @RequestParam String password) {
        try {
            String token = studentService.login(studentId, password);
            return token != null ? Result.success(token) : Result.fail("账号或密码错误");
        } catch (Exception e) {
            return Result.fail("登录异常：" + e.getMessage());
        }
    }

    /**
     * 报名面试
     */
    @PostMapping("/apply")
    @ApiOperation("面试报名")
    public Result<String> apply(@RequestBody InterviewStudent interviewStudent) {
        try {
            boolean success = interviewStudentService.apply(interviewStudent);
            return success ? Result.success("报名成功") : Result.fail("报名失败");
        } catch (Exception e) {
            return Result.fail("报名异常：" + e.getMessage());
        }
    }

    /**
     * 查询面试结果
     */
    @GetMapping("/interview/result")
    @ApiOperation("查询面试结果")
    public Result<InterviewResult> getInterviewResult(@RequestParam String studentId) {
        try {
            InterviewResult result = interviewResultService.getByStudentId(studentId);
            return result != null ? Result.success(result) : Result.fail("暂无面试结果");
        } catch (Exception e) {
            return Result.fail("查询异常：" + e.getMessage());
        }
    }

    /**
     * 获取方向数据
     */
    @GetMapping("/direction/data")
    @ApiOperation("获取方向数据")
    public Result<List<String>> getDirectionData() {
        try {
            List<String> directions = studentService.getDirectionData();
            return Result.success(directions);
        } catch (Exception e) {
            return Result.fail("获取数据异常：" + e.getMessage());
        }
    }

    /**
     * 获取个人信息
     */
    @GetMapping("/info")
    @ApiOperation("获取个人信息")
    public Result<Student> getStudentInfo(@RequestParam String studentId) {
        try {
            Student student = studentService.getByStudentId(studentId);
            return student != null ? Result.success(student) : Result.fail("学生不存在");
        } catch (Exception e) {
            return Result.fail("查询异常：" + e.getMessage());
        }
    }
}

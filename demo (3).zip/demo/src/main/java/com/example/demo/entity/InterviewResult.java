package com.example.demo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("interview_result") // 对应数据库表名
public class InterviewResult {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private String studentId; // 学生学号
    private String studentName; // 学生姓名
    private Integer status; // 0-未面试，1-通过，2-未通过
}
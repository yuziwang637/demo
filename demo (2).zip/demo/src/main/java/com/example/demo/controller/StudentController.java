package com.example.demo.controller;

import com.example.demo.entity.Student;
import com.example.demo.service.StudentService;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/students")
@Api(tags = "学生管理接口")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping
    @ApiOperation("分页查询所有学生")
    public ResponseEntity<PageInfo<Student>> findAll(
            @RequestParam(defaultValue = "1") int pageNum,
            @RequestParam(defaultValue = "10") int pageSize) {
        PageInfo<Student> pageInfo = studentService.findAll(pageNum, pageSize);
        return new ResponseEntity<>(pageInfo, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    @ApiOperation("根据ID查询学生")
    public ResponseEntity<Student> findById(@PathVariable Integer id) {
        Student student = studentService.findById(id);
        if (student != null) {
            return new ResponseEntity<>(student, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @GetMapping("/studentId/{studentId}")
    @ApiOperation("根据学号查询学生")
    public ResponseEntity<Student> findByStudentId(@PathVariable String studentId) {
        Student student = studentService.findByStudentId(studentId);
        if (student != null) {
            return new ResponseEntity<>(student, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    @ApiOperation("添加学生")
    public ResponseEntity<String> addStudent(@RequestBody Student student) {
        boolean success = studentService.addStudent(student);
        if (success) {
            return new ResponseEntity<>("学生添加成功", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<>("学生添加失败，可能学号已存在", HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/{id}")
    @ApiOperation("更新学生信息")
    public ResponseEntity<String> updateStudent(
            @PathVariable Integer id,
            @RequestBody Student student) {
        // 确保ID一致
        student.setId(id);
        boolean success = studentService.updateStudent(student);
        if (success) {
            return new ResponseEntity<>("学生信息更新成功", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("学生信息更新失败", HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    @ApiOperation("删除学生")
    public ResponseEntity<String> deleteStudent(@PathVariable Integer id) {
        boolean success = studentService.deleteStudent(id);
        if (success) {
            return new ResponseEntity<>("学生删除成功", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("学生删除失败", HttpStatus.NOT_FOUND);
        }
    }
}
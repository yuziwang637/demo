package com.example.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo.entity.Student;
import com.github.pagehelper.PageInfo;

public interface StudentService extends IService<Student> {
    /**
     * 分页查询学生信息
     * @param pageNum 页码
     * @param pageSize 每页数量
     * @return 分页学生列表
     */
    PageInfo<Student> findAll(int pageNum, int pageSize);

    /**
     * 根据ID查询学生
     * @param id 学生ID
     * @return 学生信息
     */
    Student findById(Integer id);

    /**
     * 根据学号查询学生
     * @param studentId 学号
     * @return 学生信息
     */
    Student findByStudentId(String studentId);

    /**
     * 添加学生
     * @param student 学生信息
     * @return 是否添加成功
     */
    boolean addStudent(Student student);

    /**
     * 更新学生信息
     * @param student 学生信息
     * @return 是否更新成功
     */
    boolean updateStudent(Student student);

    /**
     * 删除学生
     * @param id 学生ID
     * @return 是否删除成功
     */
    boolean deleteStudent(Integer id);
}
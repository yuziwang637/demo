package com.example.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo.entity.Student;
import com.example.demo.mapper.StudentMapper;
import com.example.demo.service.StudentService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceImpl extends ServiceImpl<StudentMapper, Student> implements StudentService {

    @Override
    public PageInfo<Student> findAll(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        return new PageInfo<>(baseMapper.selectList(null));
    }

    @Override
    public Student findById(Integer id) {
        return baseMapper.selectById(id);
    }

    @Override
    public Student findByStudentId(String studentId) {
        QueryWrapper<Student> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("student_id", studentId);
        return baseMapper.selectOne(queryWrapper);
    }

    @Override
    public boolean addStudent(Student student) {
        // 检查学号是否已存在
        if (findByStudentId(student.getStudentId()) != null) {
            return false;
        }
        return baseMapper.insert(student) > 0;
    }

    @Override
    public boolean updateStudent(Student student) {
        return baseMapper.updateById(student) > 0;
    }

    @Override
    public boolean deleteStudent(Integer id) {
        return baseMapper.deleteById(id) > 0;
    }
}